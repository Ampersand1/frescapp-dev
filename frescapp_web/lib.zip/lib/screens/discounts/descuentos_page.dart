import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:frescapp/models/product.dart';

class DescuentosPage extends StatefulWidget {
  const DescuentosPage({super.key});

  @override
  State<DescuentosPage> createState() => _DescuentosPageState();
}

class _DescuentosPageState extends State<DescuentosPage> {
  final TextEditingController _searchController = TextEditingController();
  String searchQuery = '';

  final Color verdePrincipal = const Color(0xFF5E6B4E);
  final Color fondo = const Color(0xFFF8F8E8);

  // 🧺 Lista de productos locales (puedes reemplazar por carga desde JSON o API)
  final List<Product> productos = [
    // 🥦 Verduras
    Product(
      name: 'Cebolla Cabezona Roja Sin Pelar – Kg',
      category: 'Verduras',
      priceSale: 3724,
      discount: 20,
      image: 'assets/products/BOG-CAT001-00013.png',
      quantity: 0,
    ),
    Product(
      name: 'Zanahoria – Kg',
      category: 'Verduras',
      priceSale: 2500,
      discount: 10,
      image: 'assets/products/zanahoria.png',
      quantity: 0,
    ),
    Product(
      name: 'Tomate Chonto – Kg',
      category: 'Verduras',
      priceSale: 3400,
      discount: 15,
      image: 'assets/products/tomate.png',
      quantity: 0,
    ),
    Product(
      name: 'Lechuga Batavia – Und',
      category: 'Verduras',
      priceSale: 1800,
      discount: 5,
      image: 'assets/products/lechuga.png',
      quantity: 0,
    ),
    Product(
      name: 'Pimentón Rojo – Kg',
      category: 'Verduras',
      priceSale: 4800,
      discount: 18,
      image: 'assets/products/pimenton.png',
      quantity: 0,
    ),

    // 🍎 Frutas
    Product(
      name: 'Lulo – Kg',
      category: 'Frutas',
      priceSale: 18620,
      discount: 15,
      image: 'assets/products/BOG-CAT002-00012.png',
      quantity: 0,
    ),
    Product(
      name: 'Manzana Roja',
      category: 'Frutas',
      priceSale: 5200,
      discount: 25,
      image: 'assets/products/BOG-CAT003-00002.png',
      quantity: 0,
    ),
    Product(
      name: 'Piña',
      category: 'Frutas',
      priceSale: 3000,
      discount: 10,
      image: 'assets/products/BOG-CAT004-00004.png',
      quantity: 0,
    ),
    Product(
      name: 'Banano Criollo – Kg',
      category: 'Frutas',
      priceSale: 2500,
      discount: 12,
      image: 'assets/products/banano.png',
      quantity: 0,
    ),
    Product(
      name: 'Uvas Verdes – Bandeja',
      category: 'Frutas',
      priceSale: 7800,
      discount: 20,
      image: 'assets/products/uvas.png',
      quantity: 0,
    ),
    Product(
      name: 'Mango Tommy – Und',
      category: 'Frutas',
      priceSale: 2500,
      discount: 10,
      image: 'assets/products/mango.png',
      quantity: 0,
    ),
    Product(
      name: 'Papaya – Kg',
      category: 'Frutas',
      priceSale: 3100,
      discount: 8,
      image: 'assets/products/papaya.png',
      quantity: 0,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final productosFiltrados = productos
        .where((p) =>
            (p.name ?? '').toLowerCase().contains(searchQuery.toLowerCase()))
        .toList();

    final categorias =
        productosFiltrados.map((p) => p.category ?? '').toSet().toList();

    return Scaffold(
      backgroundColor: fondo,
      appBar: AppBar(
        title: const Text(
          'PromFres',
          style: TextStyle(fontFamily: 'Poppins'),
        ),
        backgroundColor: verdePrincipal,
        foregroundColor: Colors.white,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            // 🔍 Barra de búsqueda
            TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar productos...',
                prefixIcon: const Icon(Icons.search),
                filled: true,
                fillColor: Colors.white,
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              onChanged: (value) {
                setState(() => searchQuery = value);
              },
            ),
            const SizedBox(height: 12),

            // 🎠 Carruseles por categoría
            Expanded(
              child: ListView.builder(
                itemCount: categorias.length,
                itemBuilder: (context, index) {
                  final categoria = categorias[index];
                  final productosCategoria = productosFiltrados
                      .where((p) => p.category == categoria)
                      .toList();

                  return Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // 🔠 Título de categoría
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 8.0),
                        child: Text(
                          categoria,
                          style: TextStyle(
                            fontFamily: 'Poppins',
                            fontWeight: FontWeight.bold,
                            fontSize: 18,
                            color: verdePrincipal,
                          ),
                        ),
                      ),

                      // 🧩 Carrusel horizontal
                      SizedBox(
                        height: 250,
                        child: ListView.builder(
                          scrollDirection: Axis.horizontal,
                          physics: const BouncingScrollPhysics(),
                          itemCount: productosCategoria.length,
                          itemBuilder: (context, i) {
                            final producto = productosCategoria[i];
                            final precioDescuento = producto.priceSale != null
                                ? producto.priceSale! *
                                    (1 - (producto.discount ?? 0) / 100)
                                : 0.0;
                            bool isHovered = false;

                            return StatefulBuilder(
                              builder: (context, setStateCard) {
                                return MouseRegion(
                                  onEnter: (_) =>
                                      setStateCard(() => isHovered = true),
                                  onExit: (_) =>
                                      setStateCard(() => isHovered = false),
                                  child: AnimatedContainer(
                                    duration: const Duration(milliseconds: 200),
                                    width: 170,
                                    margin: const EdgeInsets.only(right: 12),
                                    decoration: BoxDecoration(
                                      color: isHovered
                                          ? Colors.grey.shade200
                                          : Colors.white,
                                      borderRadius: BorderRadius.circular(12),
                                      boxShadow: [
                                        if (isHovered)
                                          BoxShadow(
                                            color: Colors.black26,
                                            blurRadius: 8,
                                            offset: const Offset(0, 4),
                                          ),
                                      ],
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.stretch,
                                      children: [
                                        ClipRRect(
                                          borderRadius:
                                              const BorderRadius.vertical(
                                                  top: Radius.circular(12)),
                                          child: Image.asset(
                                            producto.image ?? '',
                                            height: 110,
                                            fit: BoxFit.cover,
                                            errorBuilder:
                                                (context, error, stackTrace) {
                                              return Container(
                                                height: 110,
                                                color: Colors.grey.shade100,
                                                child: const Icon(
                                                  Icons.image_not_supported,
                                                  size: 40,
                                                  color: Colors.grey,
                                                ),
                                              );
                                            },
                                          ),
                                        ),
                                        Padding(
                                          padding: const EdgeInsets.all(6),
                                          child: Column(
                                            children: [
                                              Text(
                                                producto.name ?? '',
                                                style: const TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.bold,
                                                  fontSize: 13,
                                                ),
                                                textAlign: TextAlign.center,
                                                maxLines: 2,
                                                overflow: TextOverflow.ellipsis,
                                              ),
                                              Text(
                                                'Antes: \$${NumberFormat('#,###').format(producto.priceSale ?? 0)}',
                                                style: const TextStyle(
                                                  decoration: TextDecoration
                                                      .lineThrough,
                                                  color: Colors.red,
                                                  fontSize: 11.5,
                                                ),
                                              ),
                                              Text(
                                                'Ahora: \$${NumberFormat('#,###').format(precioDescuento)}',
                                                style: TextStyle(
                                                  fontFamily: 'Poppins',
                                                  fontWeight: FontWeight.bold,
                                                  color: verdePrincipal,
                                                  fontSize: 13.5,
                                                ),
                                              ),
                                              const SizedBox(height: 4),
                                              Row(
                                                mainAxisAlignment:
                                                    MainAxisAlignment.center,
                                                children: [
                                                  IconButton(
                                                    icon: const Icon(
                                                      Icons.remove_circle,
                                                      color: Colors.redAccent,
                                                    ),
                                                    onPressed: () {
                                                      setState(() {
                                                        if ((producto.quantity ??
                                                                0) >
                                                            0) {
                                                          producto.quantity =
                                                              (producto.quantity ??
                                                                      0) -
                                                                  1;
                                                        }
                                                      });
                                                    },
                                                  ),
                                                  Text(
                                                    '${producto.quantity?.toInt() ?? 0}',
                                                    style: const TextStyle(
                                                      fontSize: 14,
                                                      fontFamily: 'Poppins',
                                                    ),
                                                  ),
                                                  IconButton(
                                                    icon: Icon(
                                                      Icons.add_circle,
                                                      color: verdePrincipal,
                                                    ),
                                                    onPressed: () {
                                                      setState(() {
                                                        producto.quantity =
                                                            (producto.quantity ??
                                                                    0) +
                                                                1;
                                                      });
                                                    },
                                                  ),
                                                ],
                                              ),
                                            ],
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                );
                              },
                            );
                          },
                        ),
                      ),
                      const SizedBox(height: 20),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
